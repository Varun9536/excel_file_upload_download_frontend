import React, { useEffect, useState } from 'react'
import "./filelist.css"

export default function Fileslist() {

    const [list, setlist] = useState("")

    const file_list = async () => {

        let result = await fetch("http://localhost:3000/v1/getfile")

        result = await result.json()

        setlist(result.data)

        console.log(result)

    }


    useEffect(() => {
        file_list()
    }, [])



    const get_file = async (e) => {


        let result = await fetch("http://localhost:3000/v1/onefile", {
            method: "post",
            body: JSON.stringify({ id: e.target.id }),
            headers: {
                "Content-Type": "application/json"
            }
        })

        result = await result.json()
        console.log(result.data[0].data)



    }







    return (
        <div className="container">
            <div className="list_heading" style={{ fontSize: "25px", fontFamily: "cursive", textAlign: "center" }}> Files List</div>


            <div className="files" style={{ padding: "20px 0px", height: "500px", overflow: "auto" }} >
                {list && list.map((item) =>
                (
                    <>
                        <div style={{ margin: "20px 0px", border: "2px solid green", padding: "10px 0px", borderRadius: "10px" }}>
                            <span style={{ fontSize: "20px", margin: "0px 80px" }}>{item.name}</span>
                            <span style={{ fontSize: "20px", margin: "0px 80px" }} >{item.createdAt}</span>
                            <button style={{ fontSize: "17px", padding: "7px 20px", borderRadius: "15px", border: "none", margin: "0px 30px", background: " #009933", color: "white" }} id={item._id} onClick={get_file}>Download</button>
                            {/* <button style={{ fontSize: "17px", padding: "7px 20px", borderRadius: "15px", border: "none"  , background : "#bb2d3b" , color : "white"  }} id={item.id}>Delete</button> */}


                        </div>

                    </>

                ))}


            </div>
        </div>
    )
}
